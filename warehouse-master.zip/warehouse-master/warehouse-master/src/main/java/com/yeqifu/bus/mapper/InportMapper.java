package com.yeqifu.bus.mapper;

import com.yeqifu.bus.entity.Inport;
import com.baomidou.mybatisplus.core.mapper.BaseMapper;
import org.apache.ibatis.annotations.Mapper;

@Mapper
public interface InportMapper extends BaseMapper<Inport> {

}
