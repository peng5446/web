package com.yeqifu.bus.service;

import com.yeqifu.bus.entity.Sales;
import com.baomidou.mybatisplus.extension.service.IService;


public interface ISalesService extends IService<Sales> {

}
