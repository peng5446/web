package com.yeqifu.sys.service;

import com.yeqifu.sys.entity.Notice;
import com.baomidou.mybatisplus.extension.service.IService;


public interface INoticeService extends IService<Notice> {

}
