package com.yeqifu.bus.service;

import com.yeqifu.bus.entity.Inport;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IInportService extends IService<Inport> {

}
