package com.yeqifu.sys.service;

import com.yeqifu.sys.entity.Loginfo;
import com.baomidou.mybatisplus.extension.service.IService;


public interface ILoginfoService extends IService<Loginfo> {

}
