package com.yeqifu.sys.service;

import com.yeqifu.sys.entity.Permission;
import com.baomidou.mybatisplus.extension.service.IService;


public interface IPermissionService extends IService<Permission> {

}
